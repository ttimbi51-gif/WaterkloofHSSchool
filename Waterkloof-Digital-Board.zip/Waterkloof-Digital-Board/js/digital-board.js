const slides=[
{t:'Welcome',d:'Welcome to Waterkloof Hills Secondary School'},
{t:'Admissions',d:'Admissions for 2027 are now open.'},
{t:'Sports',d:'Support our teams this Friday.'},
{t:'Academics',d:'Saturday classes for Grade 12 continue.'}
];
let i=0;
function rotate(){
document.getElementById('slideTitle').textContent=slides[i].t;
document.getElementById('slideText').textContent=slides[i].d;
i=(i+1)%slides.length;
}
rotate();
setInterval(rotate,5000);
function clock(){
const d=new Date();
document.getElementById('clock').textContent=d.toLocaleTimeString()+" | "+d.toDateString();
}
clock();
setInterval(clock,1000);
